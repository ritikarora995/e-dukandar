from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    #url dispatching
    path("", views.index,name='index'),
    path("contact/", views.contact,name='contact'),
    path("trending/", views.trending,name='trending'),
    path("search", views.search, name='search')
    
]
