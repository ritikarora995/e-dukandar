from django.db import models

class Device(models.Model):

    shope1_item1=models.IntegerField()
    shope1_item2=models.IntegerField()
    shope1_item3=models.IntegerField()
    shope1_item4=models.IntegerField()
    shope1_item5=models.IntegerField()
    shope2_item1=models.IntegerField()
    shope2_item2=models.IntegerField()
    shope2_item3=models.IntegerField()
    shope2_item4=models.IntegerField()
    shope2_item5=models.IntegerField()
    Holiday=models.IntegerField()

# Create your models here.
class Contact(models.Model):
    name=models.CharField(max_length=122)
    email=models.CharField(max_length=122)
    desc=models.TextField()
    date=models.DateField()

    def __str__(self): 
        return self.name

class Dataset(Device):
   pass

