from home.views import contact
from django.contrib import admin
from home.models import Contact, Dataset
from import_export.admin import ImportExportModelAdmin


admin.site.register(Contact)

admin.site.register(Dataset)
class ViewAdmin(ImportExportModelAdmin):
    pass

