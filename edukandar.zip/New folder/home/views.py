from django.shortcuts import render, HttpResponse
from datetime import datetime
from home.models import Contact
from django.contrib import messages

# Create your views here.
def index(request):
    context= {
        "variable":"this is sent"
    }
    
    return render(request, 'home/index.html', context)
    

def contact(request):
    if request.method== "POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        desc=request.POST.get('desc')
        contact =Contact(name=name, email=email, desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, 'Your message has reached us, Thank You!')
        
    return render(request, 'home/contact.html')

def trending(request):
    return render(request, 'home/trending.html')

def search(request):
    if request.method == "POST":
        searched = request.POST['searched']

        return render(request, 'home/trending.html', {'searched': searched})
    #return HttpResponse("this is search")

